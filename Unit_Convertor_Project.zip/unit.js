const conversions = [
  {
    property: "Acceleration",
    units: [
      { name: "Meter/sq.sec (m/sec^2)", factor: 1 },
      { name: "Foot/sq.sec (ft/sec^2)", factor: 0.3048 },
      { name: "G (g)", factor: 9.80665 },
      { name: "Inch/sq.sec (in/sec^2)", factor: 2.54e-2 },
    ],
  },
  {
    property: "Area",
    units: [
      { name: "Square meter (m^2)", factor: 1 },
      { name: "Acre (acre)", factor: 4046.856 },
      { name: "Hectare", factor: 10000 },
      { name: "Square centimeter", factor: 0.0001 },
      { name: "Square kilometer", factor: 1000000 },
      { name: "Square foot (ft^2)", factor: 9.290304e-2 },
      { name: "Square inch (in^2)", factor: 6.4516e-4 },
    ],
  },
  {
    property: "Energy",
    units: [
      { name: "Joule (J)", factor: 1 },
      { name: "Calorie (SI) (cal)", factor: 4.1868 },
      { name: "Electron volt (eV)", factor: 1.6021e-19 },
      { name: "Volt-coulomb (V Cb)", factor: 1 },
    ],
  },
  {
    property: "Force",
    units: [
      { name: "Newton (N)", factor: 1 },
      { name: "Dyne (dy)", factor: 0.00001 },
      { name: "Kilogram force (kgf)", factor: 9.80665 },
    ],
  },
  {
    property: "Length",
    units: [
      { name: "Meter (m)", factor: 1 },
      { name: "Angstrom (A')", factor: 1e-10 },
      { name: "Astronomical unit (AU)", factor: 1.49598e11 },
      { name: "Centimeter (cm)", factor: 0.01 },
      { name: "Kilometer (km)", factor: 1000 },
      { name: "Fermi (fm)", factor: 1e-15 },
      { name: "Foot (ft)", factor: 0.3048 },
      { name: "Inch (in)", factor: 0.0254 },
      { name: "Light year (LY)", factor: 9.46055e15 },
      { name: "Micrometer (mu-m)", factor: 0.000001 },
      { name: "Millimeter (mm)", factor: 0.001 },
      { name: "Nanometer (nm)", factor: 1e-9 },
      { name: "Mile", factor: 1609.344 },
      { name: "Picometer (pm)", factor: 1e-12 },
      { name: "Yard (yd)", factor: 0.9144 },
    ],
  },
  {
    property: "Mass",
    units: [
      { name: "Kilogram (kgr)", factor: 1 },
      { name: "Gram (gr)", factor: 0.001 },
      { name: "Milligram (mgr)", factor: 1e-6 },
      { name: "Microgram (mu-gr)", factor: 1e-9 },
      { name: "Carat (metric)(ct)", factor: 0.0002 },
      { name: "Ton (metric)", factor: 1000 },
    ],
  },
  {
    property: "Power",
    units: [
      { name: "Watt (W)", factor: 1 },
      { name: "Kilowatt (kW)", factor: 1000 },
      { name: "Megawatt (MW)", factor: 1000000 },
      { name: "Milliwatt (mW)", factor: 0.001 },
      { name: "Calorie (thermo)/second", factor: 4.184 },
      { name: "Horsepower (electric)", factor: 746 },
    ],
  },
  {
    property: "Temperature",
    units: [
      { name: "Degrees Celsius ('C)", factor: 1 },
      { name: "Degrees Fahrenheit ('F)", factor: 0.555555555555 },
      { name: "Degrees Kelvin ('K)", factor: 1 },
    ],
    tempIncrement: [0, -32, -273.15],
  },
  {
    property: "Time",
    units: [
      { name: "Second (sec)", factor: 1 },
      { name: "Day (mean solar)", factor: 8.64e4 },
      { name: "Hour (mean solar)", factor: 3600 },
      { name: "Minute (mean solar)", factor: 60 },
      { name: "Month (mean calendar)", factor: 2628000 },
      { name: "Year (calendar)", factor: 31536000 },
    ],
  },
  {
    property: "Velocity & Speed",
    units: [
      { name: "Meter/second (m/sec)", factor: 1 },
      { name: "Kilometer/hour (kph)", factor: 0.2777778 },
      { name: "Mile (US)/hour (mph)", factor: 0.44707 },
      { name: "Mile (US)/minute", factor: 26.8224 },
      { name: "Mile (US)/second", factor: 1609.344 },
      { name: "Speed of light (c)", factor: 299792458 },
    ],
  },
  {
    property: "Volume & Capacity",
    units: [
      { name: "Cubic Meter (m^3)", factor: 1 },
      { name: "Cubic centimeter", factor: 0.000001 },
      { name: "Cubic millimeter", factor: 0.000000001 },
      { name: "Cubic inch (in^3)", factor: 0.00001638706 },
      { name: "Liter", factor: 0.001 },
    ],
  },
 
];

function updateUnitMenu(propMenu, unit_menu) {
  const propIndex = propMenu.selectedIndex;
  const units = conversions[propIndex].units;
  fillMenuWithArray(unit_menu, units);
}

function fillMenuWithArray(menu, array) {
  menu.innerHTML = array.map((unit) => `<option>${unit.name}</option>`).join("");
}
function fillMenuArray(menu, array) {
  console.log(array[0].property)
  menu.innerHTML = array.map((unit) => `<option>${unit.property}</option>`).join("");
}

function calUnit(srcForm, TarForm) {
  const sourceValue = parseFloat(srcForm.unit_input.value);

  if ( sourceValue === 0 || !isNaN(sourceValue)) {
    srcForm.unit_input.value = sourceValue;
    convertFromTo(srcForm, TarForm);
  }
}
console.log(conversions[1].units[1].factor)
function convertFromTo(srcForm, TarForm) {
  const propIndex = document.property_form.the_menu.selectedIndex;
  const sourceIndex = srcForm.unit_menu.selectedIndex;
  const sourceFactor = conversions[propIndex].units[sourceIndex].factor;
  const targetIndex = TarForm.unit_menu.selectedIndex;
  const targetFactor = conversions[propIndex].units[targetIndex].factor;
  let result = srcForm.unit_input.value;

  if (conversions[propIndex].property === "Temperature") {
    result = parseFloat(result) + conversions[propIndex].units[sourceIndex].tempIncrement;
  }

  result = (result * sourceFactor) / targetFactor;

  if (conversions[propIndex].property === "Temperature") {
    result = parseFloat(result) - conversions[propIndex].units[targetIndex].tempIncrement;
  }

  TarForm.unit_input.value = result;
}

function initialize() {
  const propertyMenu = document.property_form.the_menu;
 
  const unitMenuA = document.form_A.unit_menu;
  const unitMenuB = document.form_B.unit_menu;

  fillMenuWithArray(propertyMenu, conversions);
  fillMenuArray(propertyMenu, conversions);

  propertyMenu.addEventListener("change", () => {
    updateUnitMenu(propertyMenu, unitMenuA);
    updateUnitMenu(propertyMenu, unitMenuB);
  });

  updateUnitMenu(propertyMenu, unitMenuA);
  updateUnitMenu(propertyMenu, unitMenuB);
}

window.addEventListener("load", initialize);

document
  .querySelector(".numbersonly")
  .addEventListener("keydown", function (e) {
    const key = e.keyCode ? e.keyCode : e.which;
    const allowedKeys = [
      8,9,13,27,46,110,190,65,67,86,35,36,37,38,39,40,48,49,50,51,52,53,54,55,56,57,96,97,98,99,100,101,102,103,104,105,
    ];

    if (!allowedKeys.includes(key)) {
      e.preventDefault();
    }
  });